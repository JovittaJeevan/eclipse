package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class browserstrack {
       
WebDriver driver;
public browserstrack(WebDriver driver) {
	this.driver =driver;
	}
By clickable = By.id("signupModalProductButton");

public void click() {
	driver.findElement(clickable);
}
}

