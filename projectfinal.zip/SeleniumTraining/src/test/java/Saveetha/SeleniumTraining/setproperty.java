package Saveetha.SeleniumTraining;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


public class setproperty {
	WebDriver d;
@BeforeClass
	public void driverstart() throws InterruptedException {
		//System.setProperty("webdriver.chrome.driver", "C:\\driver\\SeleniumTraining\\Chromedriver\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", "C:\\driver\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		d=new ChromeDriver(options);

		
		//WebDriver driver = new ChromeDriver();
		//WebDriver driver = new EdgeDriver();
		d.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		//d.navigate().to("https://www.google.com");
		Thread.sleep(2000);
	}
	
	@AfterClass
	public void end()
	{
		
	d.quit();
}
}