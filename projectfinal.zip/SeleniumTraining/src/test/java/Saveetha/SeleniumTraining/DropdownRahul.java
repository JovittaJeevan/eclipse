package Saveetha.SeleniumTraining;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class DropdownRahul {
	static WebDriver d;
	public static void main (String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\driver\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");


		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		d=new ChromeDriver(options);
		d.get("https://rahulshettyacademy.com/dropdownsPractise/");

		Thread.sleep(2000);
		d.findElement(By.id("divpaxOptions")).click();
		for(int i=1;i<6;i++) {
	    d.findElement(By.id("hrefIncAdt")).click();
		Thread.sleep(2000);
		//Select s=new Select(d.findElement(By.id("divpaxinfo")));
	   // s.selectByIndex(2);
		//Thread.sleep(2000);
		
		
		
	}
	
}
}