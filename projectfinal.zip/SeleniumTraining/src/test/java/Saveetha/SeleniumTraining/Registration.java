package Saveetha.SeleniumTraining;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Registration extends setpropert{
     @Test 
	public void form() throws InterruptedException
       {
    	   d.findElement(By.cssSelector("input#vfb-5")).sendKeys("Jovitta"); //1st type
    	   Thread.sleep(2000);
    	   d.findElement(By.name("vfb-7")).sendKeys("A"); 
    	   Thread.sleep(2000);
    	   d.findElement(By.id("vfb-31-2")).click();
    	   Thread.sleep(2000);
    	   d.findElement(By.cssSelector("input[id=vfb-13-address]")).sendKeys("Dindigul, Tamailnadu");// 3rd type
    	   Thread.sleep(2000);
    	   d.findElement(By.cssSelector("input[name*='vfb-13[address-2]']")).sendKeys(" Township colony");//5th type
    	   Thread.sleep(2000);
    	   d.findElement(By.xpath("//input[contains(@id,'vfb-13-city')]")).sendKeys("dindigul");//contains
    	   Thread.sleep(2000);
    	   d.findElement(By.xpath("//input[@id='vfb-13-zip']")).sendKeys("000666");//basic
    	   Thread.sleep(2000);
    	   System.out.println(d.findElement(By.xpath("//label[text()='Mobile Number ']")).getText());//text
    	   Thread.sleep(2000);
    	   d.findElement(By.xpath("//input[starts-with(@name,'vfb-19')]")).sendKeys("8950484858");//start with
    	   Thread.sleep(2000);
    	   d.findElement(By.cssSelector("label.vfb-desc")).click();//2nd type
    	   Thread.sleep(2000);
    	   d.findElement(By.xpath("//input[@name='vfb-14' or @id='vfb-14']")).sendKeys("jovitta2001@gmail.com");
    	   Thread.sleep(2000);//or 
    	   d.findElement(By.xpath("//input[@name='vfb-3' and @id='vfb-3']")).sendKeys("20");
    	   Thread.sleep(2000);//and
    	   
    	   
    	   
    	   
    	   
       }
     
}
