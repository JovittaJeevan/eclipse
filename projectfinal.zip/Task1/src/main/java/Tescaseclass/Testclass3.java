package Tescaseclass;

import org.name.Task1.Scenario2;
import org.name.Task1.Scenario3;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class  Testclass3{

	WebDriver driver;
	Scenario3 EditDataBase;
	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chromedriver","pathtochromedriver");
		driver = new ChromeDriver();
		driver.get("http://userlogin");
		EditDataBase= new Scenario3(driver);
	}
	
	@Test
	public void testUerlogin() {
		EditDataBase.username("Rahul");
		EditDataBase.userpassword("12345");
		EditDataBase.clickDataBase();
		EditDataBase.EnablePermission();
		EditDataBase.customername("Jeeva");
		EditDataBase.customerpassword("3456");
		EditDataBase.clickthedatabaseform();
		EditDataBase.EditDatabase("JEEVA,8610460862, 23");
		EditDataBase.finish();
		EditDataBase.loginunsucessfull();
	
	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
