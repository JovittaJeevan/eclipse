package Tescaseclass;

import org.name.Task1.Scenarios;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Testclass1 {
	WebDriver driver;
	Scenarios addfamilymemberpage;
	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chromedriver","pathtochromedriver");
		driver = new ChromeDriver();
		driver.get("http://addfamilymember");
		addfamilymemberpage= new Scenarios(driver);
	}
	
	@Test
	public void testAddfamilymemberwithdata() {
		
		addfamilymemberpage.username("Rahul");
		addfamilymemberpage.userpassword("1234");
		addfamilymemberpage.clickdetail();
		addfamilymemberpage.clickdropdown();
		addfamilymemberpage.clickaddmembers();
		addfamilymemberpage.uploadattacement();
		addfamilymemberpage.updatethedetails("jeeva, 8610460862");
		addfamilymemberpage.clicksubmit();
		addfamilymemberpage.childdetail("jo,9629705643");
		addfamilymemberpage.clicksubmitforchild();
		addfamilymemberpage.okay();
		addfamilymemberpage.Notification();
		
		
	}
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
