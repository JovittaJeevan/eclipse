package Tescaseclass;

import org.name.Task1.Scenario2;
import org.name.Task1.Scenarios;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Testclass2 {

	
	
	
	WebDriver driver;
	Scenario2 UserLogin;
	
	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chromedriver","pathtochromedriver");
		driver = new ChromeDriver();
		driver.get("http://userlogin");
		UserLogin= new Scenario2(driver);
	}
	
	@Test
	public void testUerlogin() {
		UserLogin.username("Kamalesh");
		UserLogin.userpassword("123455");
		UserLogin.deletecustomeraccount();
		UserLogin.deleteallcustomeraccount();
		UserLogin.customerusername("jeeva");
		UserLogin.customerpassword("2345");
		UserLogin.loginunsucessfull();
		UserLogin.detailmodule();
		UserLogin.RemovedDetails();
	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
