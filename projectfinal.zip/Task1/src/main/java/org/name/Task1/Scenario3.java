package org.name.Task1;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Scenario3 {

WebDriverWait wait;
WebDriver driver;

@FindBy(xpath="enterusername")
WebElement userlogin1;


@FindBy(className="enterpassword")
WebElement userlogin2;



@FindBy(className="database")
WebElement Clickdatabase;


@FindBy(id="enablepermission")
WebElement click;

@FindBy(xpath="enablepermission")
WebElement Okaybutton;

@FindBy(className="customername")
WebElement Customerlogin1;

@FindBy(tagName="customerpassword")
WebElement Customerlogin2;

@FindBy(xpath="database")
WebElement clickthedatabase;


@FindBy(tagName="editdatabse")
WebElement editdatabase;

@FindBy(id="finishthedetails")
WebElement clickfinish;


@FindBy(xpath="recive successfull updated notification")
WebElement updatedNotification;



public Scenario3(WebDriver driver) {
	this.driver=driver;
	this.wait=new WebDriverWait(driver,Duration.ofSeconds(10));
	PageFactory.initElements(driver,this);
}
public void username (String name){
	userlogin1.sendKeys();

}
	public void userpassword(String passwords) {
		userlogin2.sendKeys();
	
}
	public void clickDataBase(){
		Clickdatabase.click();
	}
	
	public void EnablePermission(){
		click.click();
	}
	
	public void customername(String name){
		Customerlogin1.sendKeys();
	}
	
	public void customerpassword(String password){
		Customerlogin2.sendKeys();
	}
	
	public void clickthedatabaseform(){
		clickthedatabase.click();
	}
	public void EditDatabase(String name){
		editdatabase.sendKeys();
	}
	
	public void finish(){
		clickfinish.click();
	}
	public void loginunsucessfull() {
	       wait.until(ExpectedConditions.elementToBeClickable(updatedNotification));
	       updatedNotification.click();
}

}
