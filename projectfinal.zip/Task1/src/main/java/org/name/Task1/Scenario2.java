package org.name.Task1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public  class Scenario2 {
	
	
	
	WebDriverWait wait;
	WebDriver driver;
	
	@FindBy(id="username")
	WebElement userlogin;
	
	@FindBy(className="enterpassword")
	WebElement userpassword;


	@FindBy(xpath="deletingthecustomeraccount")
	WebElement clickthedeleteaccount;


	@FindBy(className="deleteallcustomeraccount")
	WebElement Deleteallaccount;

	@FindBy(id="username")
	WebElement customerlogin1;
	
	@FindBy(xpath="password")
	WebElement customerlogin2;

	@FindBy(id="loginunsucessfull")
	WebElement alertmessage;

	@FindBy(xpath="clickthedetailpage")
	WebElement clickthedetail;

	@FindBy(xpath="removedcustomerdetails")
	WebElement detailsofremovedcustomer;


	public Scenario2(WebDriver driver) {
		this.driver=driver;
		this.wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		PageFactory.initElements(driver,this);
	}
	public void username (String name){
		userlogin.sendKeys();

	}
		public void userpassword(String passwords) {
			userpassword.sendKeys();
		
	}
		public void deletecustomeraccount(){
			clickthedeleteaccount.click();
		}
		
		public void deleteallcustomeraccount(){
			Deleteallaccount.click();
		}
		
		public void customerusername(String name){
			customerlogin1.sendKeys();
		}
		
		public void customerpassword(String passwords){
			customerlogin2.sendKeys();
		}
		
		public void loginunsucessfull() {
		       wait.until(ExpectedConditions.elementToBeClickable(alertmessage));
		       alertmessage.click();
		
		}
		public void detailmodule(){
		
			clickthedetail.click();
			
		}
		
		
		public  void RemovedDetails(){
		
			detailsofremovedcustomer.click();
		}
			
		
}
