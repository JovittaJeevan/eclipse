package org.name.Task1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Scenarios {

WebDriverWait wait;
WebDriver driver;

@FindBy(css="enterusername")
WebElement username;


@FindBy(className="enterpassword")
WebElement password;

@FindBy(css="click on detailmodule")
WebElement Detailmodule;

@FindBy(xpath="click on dropdown to check the details")
WebElement Details;

@FindBy(xpath="click on add member")
WebElement Addmembers;

@FindBy(tagName="upload the attachments")
WebElement Attachment;


@FindBy(className="enter the details for a member")
WebElement updatedetails;

@FindBy(id="click on submit for adding the member")
WebElement Addmember1;

@FindBy(xpath="enter the details for child")
WebElement updatedetail;

@FindBy(css="click on submit for add the child")
WebElement Addmember2;

@FindBy(id="click on okay button after adding all the members")
WebElement okaybutton;

@FindBy(tagName="recive successfull notification")
WebElement Notification;



public Scenarios(WebDriver driver) {
	this.driver=driver;
	this.wait=new WebDriverWait(driver,Duration.ofSeconds(10));
	PageFactory.initElements(driver,this);
}
public void username (String name){
	username.sendKeys();

}
	public void userpassword(String passwords) {
		password.sendKeys();
	
}
	public void clickdetail(){
		Detailmodule.click();
	}
	
	public void clickdropdown(){
		Details.click();
	}
	
	public void clickaddmembers(){
		Addmembers.click();
	}
	
	public void uploadattacement(){
		Attachment.click();
	}
	
	public void updatethedetails(String details){
		 updatedetails.sendKeys();
	}
	public void clicksubmit(){
		Addmember1.click();
	}
	
	public void childdetail(String details){
		updatedetail.sendKeys();
	}
	
	public void clicksubmitforchild(){
		Addmember2.click();
	}

   public void okay() {
	   okaybutton.click();
   }
   
   public void Notification() {
	       wait.until(ExpectedConditions.elementToBeClickable(Notification));
	       Notification.click();;
   
}
}



