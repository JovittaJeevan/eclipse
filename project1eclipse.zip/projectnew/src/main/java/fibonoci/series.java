package fibonoci;

public class series {

	public static void main(String[] args) {
		int n = 10;
		int[] fibonaciseries = new int[n];
		fibonaciseries[0] =0;
		fibonaciseries[1] =1;
		for(int i =2;i<n;i++) {
			fibonaciseries[i] = 	fibonaciseries[i-1]+	fibonaciseries[i-2];

	}
		System.out.print("Fibonacci series:");
		for(int i=0;i<n;i++) {
			System.out.print(fibonaciseries[i]+"");
		}
		
		System.out.print("Reversed fibonacci series:");
		for(int i=n-1;i>=0;i--) {
			System.out.print(fibonaciseries[i]+"");
		}
}}
