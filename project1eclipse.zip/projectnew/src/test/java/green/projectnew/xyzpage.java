package green.projectnew;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


public  class xyzpage {

	WebDriver driver; 
	
	@FindBy(xpath="//div[@class='container-fluid ng-scope']//div[2]//div//div//div//button")
	@CacheLookup
	WebElement login;
	
	@FindBy(id="userSelect")
	@CacheLookup
	WebElement selectname;
	
	@FindBy(xpath="//button[contains(text(),'Login')]")
	@CacheLookup
	WebElement loginbutton;
	

	
	/*@FindBy(xpath="//div[@class='container-fluid ng-scope']//div[2]//div//div//div[2]//button")
    @CacheLookup
    WebElement bankmanagerlogin;*/
	
	
	
	
	public xyzpage(WebDriver driver) {
		this.driver=driver;   //constructor//same class name//no return type
	}

public void loginpage1()
{
	login.click();
}

public void selectthename()
{
	Select thename = new Select(selectname);
	thename.selectByValue("2");
}

public void loginbutton1()
{
	//loginbutton.click();
	Actions action = new Actions(driver);
	action.moveToElement(loginbutton).click().build().perform();
}

public void scroll(WebElement element) throws InterruptedException { //scroll method
	  
    ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",element);
    
    
    }
    

public  void Screeshots() throws IOException, InterruptedException {  
	TakesScreenshot screenshots=(TakesScreenshot)driver; 
		File screenshot=screenshots.getScreenshotAs(OutputType.FILE);
		File destination=new File("./screenshotssel/button.png");
		FileUtils.copyFile(screenshot,destination);
		
   }

public  void assertTextEqual(WebElement actualElement, WebElement expectedElement) { //Assertion method
	      WebElement actual = driver.findElement(By.className("btn btn-default"));
	      String a = actual.getText();
	      Assert.assertEquals(a, "login");

/*public void loginpage2()

bankmanagerlogin.click();
}*/
}}