package green.projectnew;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class Generic {
	public static WebDriver driver = new ChromeDriver();// declare globally
  
	@BeforeSuite
	public void initialize()      //create method 
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\JOVITA\\newproject\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
		driver.manage().window().maximize();                         //set the path for url
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterSuite
	public void quit()//to close 
	{
		driver.quit();
	}
}

