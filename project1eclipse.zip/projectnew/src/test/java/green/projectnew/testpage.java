package green.projectnew;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class testpage extends Generic {
	@Test
	public void testrun() throws IOException, InterruptedException
	{
		xyzpage pf = PageFactory.initElements(driver, xyzpage.class);
		
		pf.loginpage1();
		pf.selectthename();
	
		

		pf.loginbutton1();
		pf.Screeshots();

	}

}
