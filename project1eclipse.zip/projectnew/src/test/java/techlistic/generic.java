package techlistic;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class generic {




	
	public static WebDriver driver = new ChromeDriver();// declare globally
  
	@BeforeSuite
	public void initialize()      //create method 
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\JOVITA\\newproject\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();                         //set the path for url
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterSuite
	public void quit()//to close 
	{
		driver.quit();
	}
}



