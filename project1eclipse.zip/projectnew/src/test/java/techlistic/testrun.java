package techlistic;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class testrun extends generic {
	@Test
	public void test() throws IOException, InterruptedException {
		
		upload pf = PageFactory.initElements(driver, upload.class);
		
		pf.loginfirstname1("jeeva");
		pf.loginsecondname("jo");
	
		pf.scroll();

		pf.uploadimage();
		

	}



}
