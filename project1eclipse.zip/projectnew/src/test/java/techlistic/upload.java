package techlistic;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class upload {

	
	
	


	WebDriver driver; 
	
	@FindBy(name="firstname")
	@CacheLookup
	WebElement loginname;
	
	@FindBy(name="lastname")
	@CacheLookup
	WebElement loginlastname;
	
	@FindBy(id="photo")
	@CacheLookup
	WebElement uploadfile;

	
	@FindBy(id="photo")
	@CacheLookup
	WebElement uploadphoto;

	public upload(WebDriver driver) {
		this.driver=driver;   //constructor//same class name//no return type
	}

public void loginfirstname1(String string)
{
	loginname.sendKeys();
}

public void loginsecondname(String string)
{
	loginlastname.sendKeys();
}


public void scroll() throws InterruptedException { //scroll method
	  
    ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",uploadfile);
    
   
    }
public void uploadimage()
{
	uploadphoto.click();
}


	
}




