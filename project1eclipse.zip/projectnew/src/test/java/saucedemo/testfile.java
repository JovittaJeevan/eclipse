package saucedemo;

	

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class testfile extends genericfile {
	@Test
	public void testrun() throws IOException, InterruptedException
	{
		login pf = PageFactory.initElements(driver, login.class);
		
		pf.loginname1("standard_user");
		pf.loginpassword("secret_sauce");
	
	

		pf.presslogin();
		

	}
}
