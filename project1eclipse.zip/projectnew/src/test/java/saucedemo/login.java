package saucedemo;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
public class login {

	
	
	
	

		WebDriver driver; 
		
		@FindBy(id="user-name")
		@CacheLookup
		WebElement login1;
		
		@FindBy(id="password")
		@CacheLookup
		WebElement login2;
		
		@FindBy(className="submit-button btn_action")
		@CacheLookup
		WebElement loginbutton;

		public login(WebDriver driver) {
			this.driver=driver;   //constructor//same class name//no return type
		}

	public void loginname1(String name)
	{
		login1.sendKeys();
	}

	public void loginpassword(String password)
	{
		login2.sendKeys();
	}
	public void presslogin()
	{
		loginbutton.click();
	}

	

}

